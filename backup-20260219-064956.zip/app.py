import os, re, json, csv, ssl, smtplib, traceback
from datetime import datetime, timezone, time
from typing import List, Literal, Optional
from email.message import EmailMessage

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field
from tenacity import retry, stop_after_attempt, wait_exponential
import httpx

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from docx import Document
from docx.shared import Pt
from fpdf import FPDF

# --------- Config via .env ----------
from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), "engine.env"))

HOST = os.getenv("ENGINE_HOST","127.0.0.1")
PORT = int(os.getenv("ENGINE_PORT","7363"))
DATA_ROOT = os.getenv("DATA_ROOT", os.path.dirname(__file__))

OLLAMA_URL   = os.getenv("OLLAMA_URL","http://127.0.0.1:11434")
LMSTUDIO_URL = os.getenv("LMSTUDIO_URL","http://127.0.0.1:1234/v1/chat/completions")
MODEL        = os.getenv("REPLY_MODEL","qwen2.5:7b-instruct")

SMTP_ENABLED = os.getenv("SMTP_ENABLED","false").lower() == "true"
SMTP_HOST    = os.getenv("SMTP_HOST","")
SMTP_PORT    = int(os.getenv("SMTP_PORT","587") or 587)
SMTP_USER    = os.getenv("SMTP_USER","")
SMTP_PASS    = os.getenv("SMTP_PASS","")
FROM_EMAIL   = os.getenv("FROM_EMAIL","owner@example.com")
FROM_NAME    = os.getenv("FROM_NAME","Review Reply Sprint")

ONBOARDING_URL = os.getenv("ONBOARDING_URL","https://example.com/onboarding")
SAMPLES_URL    = os.getenv("SAMPLES_URL","https://example.com/samples")

STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET","")

# --------- Models ----------
class Review(BaseModel):
    rating: int = Field(ge=1, le=5)
    text: str

class Job(BaseModel):
    business_name: str
    signoff: str = "-"
    tone_style: Literal["Professional","Warm","Playful","Direct"] = "Professional"
    persona: Literal["dentist_medspa","trades","auto","restaurant","real_estate","ecom"] = "trades"
    compliance_profile: Literal["HIPAA","FTC","General"] = "General"
    private_email: Optional[str] = None
    banned_words: List[str] = []
    max_length_per_reply: int = 900
    reviews: List[Review]

class Lead(BaseModel):
    business_name: str
    email: str
    persona: Literal["dentist_medspa","trades","auto","restaurant","real_estate","ecom"] = "trades"
    compliance_profile: Literal["HIPAA","FTC","General"] = "General"
    tone_style: Literal["Professional","Warm","Playful","Direct"] = "Professional"
    signoff: str = "- Team"
    private_email: Optional[str] = None
    reviews_sample: List[Review]

# --------- Prompts ----------
SYSTEM_TMPL = """You write OWNER-VOICE replies to Google reviews.
Persona: {persona}. Compliance: {compliance}.
Rules:
- Be specific to the review; avoid templates.
- If rating <=2: apologize once and invite private follow-up at {private_email}; do not argue or include personal data.
- Max length per reply: {max_len} characters.
- Avoid banned words: {banned}.
- Tone: {tone}. End with: {signoff}
Compliance notes:
- HIPAA: never include treatment/diagnosis or PHI.
- FTC: no guarantees, legal/financial claims, or unverifiable promises.
Return ONLY a JSON array of reply strings, no extra commentary.
"""

USER_TMPL = """Business: {biz}
Reviews (rating:number, text):
{pairs}
Return ONLY a JSON array of strings: ["reply1", "reply2", ...].
"""

# --------- LLM calls ----------
async def ollama_generate(prompt: str) -> str:
    async with httpx.AsyncClient(timeout=60) as cx:
        r = await cx.post(f"{OLLAMA_URL}/api/generate", json={"model": MODEL, "prompt": prompt, "stream": False})
        if r.status_code != 200:
            raise RuntimeError(f"Ollama error: {r.text}")
        return r.json().get("response","")

async def lmstudio_chat(system: str, user: str) -> str:
    async with httpx.AsyncClient(timeout=60) as cx:
        r = await cx.post(LMSTUDIO_URL, json={
            "model":"local-model",
            "messages":[{"role":"system","content":system},{"role":"user","content":user}],
            "temperature":0.3
        })
        if r.status_code != 200:
            raise RuntimeError(f"LM Studio error: {r.text}")
        data = r.json()
        return data["choices"][0]["message"]["content"]

def json_only(text: str):
    m = re.search(r"\[[\s\S]*\]")
    if not m: raise ValueError("No JSON array found in model output")
    return json.loads(m.group(0))

def qa_guard(reply: str, banned: List[str], max_len: int):
    s = reply.strip()
    if len(s) > max_len: s = s[:max_len-1] + "…"
    low = s.lower()
    for w in banned:
        if w.lower() in low:
            s = s.replace(w, "***")
    return s

@retry(stop=stop_after_attempt(2), wait=wait_exponential(multiplier=1, min=1, max=4))
async def generate_replies(job: Job):
    private_email = job.private_email or "contact us"
    sys_prompt = SYSTEM_TMPL.format(
        persona=job.persona,
        compliance=job.compliance_profile,
        private_email=private_email,
        max_len=job.max_length_per_reply,
        banned=", ".join(job.banned_words) if job.banned_words else "none",
        tone=job.tone_style,
        signoff=job.signoff
    )
    pairs = "\n".join([f"- ({r.rating}) {r.text}" for r in job.reviews])
    user_prompt = USER_TMPL.format(biz=job.business_name, pairs=pairs)
    try:
        raw = await ollama_generate(f"{sys_prompt}\n\n{user_prompt}")
    except Exception:
        raw = await lmstudio_chat(sys_prompt, user_prompt)
    arr = json_only(raw)
    out = [qa_guard(a, job.banned_words, job.max_length_per_reply) for a in arr]
    if len(out) != len(job.reviews):
        out = (out + [f"Thank you for your feedback. – {job.signoff}"]*(len(job.reviews)-len(out)))[:len(job.reviews)]
    return out

# --------- Artifacts: DOCX / PDF ----------
def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def build_docx(path: str, business: str, reviews: List[Review], replies: List[str], signoff: str):
    doc = Document()
    doc.add_heading(f"{business} — Review Replies", level=0)
    for i,(rv,rep) in enumerate(zip(reviews, replies), start=1):
        doc.add_heading(f"Review #{i} — {rv.rating}★", level=2)
        doc.add_paragraph(rv.text)
        para = doc.add_paragraph()
        run = para.add_run(rep)
        font = run.font; font.size = Pt(11)
    doc.add_paragraph()
    doc.add_paragraph(f"{signoff}")
    doc.save(path)

def build_pdf(path: str, business: str, reviews: List[Review], replies: List[str], signoff: str):
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial","B",16)
    pdf.cell(0,10, f"{business} — Review Replies", ln=1)
    pdf.set_font("Arial","",12)
    for i,(rv,rep) in enumerate(zip(reviews, replies), start=1):
        pdf.set_font("Arial","B",12); pdf.cell(0,8, f"Review #{i} — {rv.rating}★", ln=1)
        pdf.set_font("Arial","",12); pdf.multi_cell(0,6, rv.text)
        pdf.set_font("Arial","I",12); pdf.multi_cell(0,6, rep); pdf.ln(2)
    pdf.ln(3)
    pdf.set_font("Arial","",11); pdf.cell(0,6, signoff, ln=1)
    pdf.output(path)

# --------- Email ----------
def send_email(to_addr: str, subject: str, body: str, attachments: Optional[List[str]]=None):
    msg = EmailMessage()
    msg["From"] = f"{FROM_NAME} <{FROM_EMAIL}>"
    msg["To"] = to_addr
    msg["Subject"] = subject
    msg.set_content(body)

    for a in attachments or []:
        with open(a,"rb") as f:
            data = f.read()
        maintype, subtype = ("application","octet-stream")
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=os.path.basename(a))

    if SMTP_ENABLED and SMTP_HOST and SMTP_USER and SMTP_PASS:
        ctx = ssl.create_default_context()
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as s:
            s.starttls(context=ctx)
            s.login(SMTP_USER, SMTP_PASS)
            s.send_message(msg)
    else:
        # Fallback: save .eml to outbox so nothing blocks unattended
        outbox = os.path.join(DATA_ROOT,"outbox")
        ensure_dir(outbox)
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        fn = os.path.join(outbox, f"{ts}-{subject.replace(' ','_')}.eml")
        with open(fn,"wb") as f:
            f.write(msg.as_bytes())

# --------- KPI ----------
def kpi_append(row: dict):
    kpi_csv = os.path.join(DATA_ROOT,"kpi","kpi.csv")
    header = ["Date","Leads","Qualified","Sprints","MRR","Refunds","COGS"]
    newfile = not os.path.exists(kpi_csv)
    with open(kpi_csv,"a",newline="",encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=header)
        if newfile: w.writeheader()
        w.writerow(row)

def weekly_kpi_job():
    # Minimal rollup; extend as needed
    kpi_append({
        "Date": datetime.now().date().isoformat(),
        "Leads": 0, "Qualified": 0, "Sprints": 0, "MRR": 0, "Refunds": 0, "COGS": 0
    })

# --------- App & scheduler ----------
app = FastAPI(title="Review Reply Orchestrator", version="1.0.0")

sched = BackgroundScheduler(timezone="local")
# Mondays 08:00 local — adjustable
sched.add_job(weekly_kpi_job, CronTrigger(day_of_week="mon", hour=8, minute=0))
sched.start()

# --------- Helpers ----------
def job_dirs(business: str):
    safe = re.sub(r"[^a-zA-Z0-9._-]+","_", business).strip("_")
    base = os.path.join(DATA_ROOT,"clients", safe, datetime.now().strftime("%Y-%m-%d"))
    ensure_dir(base)
    return base

# --------- Endpoints ----------
@app.get("/healthz")
def healthz():
    return {"ok": True, "port": PORT, "model": MODEL}

@app.post("/generate_replies")
async def api_generate(job: Job):
    if not job.reviews: raise HTTPException(400,"No reviews")
    replies = await generate_replies(job)
    return {"business_name": job.business_name, "replies": replies}

@app.post("/lead-intake")
async def lead_intake(lead: Lead):
    # Generate 5-sample replies and email them
    job = Job(
        business_name=lead.business_name,
        signoff=lead.signoff,
        tone_style=lead.tone_style,
        persona=lead.persona,
        compliance_profile=lead.compliance_profile,
        private_email=lead.private_email,
        banned_words=["guarantee"],
        max_length_per_reply=500,
        reviews=lead.reviews_sample
    )
    replies = await generate_replies(job)
    base = job_dirs(lead.business_name)
    pdf = os.path.join(base, "sample-5.pdf")
    docx= os.path.join(base, "sample-5.docx")
    build_pdf(pdf, lead.business_name, job.reviews, replies, job.signoff)
    build_docx(docx, lead.business_name, job.reviews, replies, job.signoff)
    send_email(
        to_addr=lead.email,
        subject=f"{lead.business_name} — 5 tailored review replies",
        body=(f"Preview attached. If you like the tone, start the 50-reply Sprint here:\n{SAMPLES_URL}\n"),
        attachments=[pdf, docx]
    )
    return {"ok": True, "sent": True, "files": [pdf, docx]}

class FullIntake(BaseModel):
    business_name: str
    email: str
    persona: Literal["dentist_medspa","trades","auto","restaurant","real_estate","ecom"] = "trades"
    compliance_profile: Literal["HIPAA","FTC","General"] = "General"
    tone_style: Literal["Professional","Warm","Playful","Direct"] = "Professional"
    signoff: str = "- Owner"
    private_email: Optional[str] = None
    banned_words: List[str] = []
    max_length_per_reply: int = 900
    reviews: List[Review]

@app.post("/intake-submit")
async def intake_submit(payload: FullIntake):
    job = Job(**payload.dict())
    replies = await generate_replies(job)
    base = job_dirs(payload.business_name)
    pdf  = os.path.join(base, "replies-50.pdf")
    docx = os.path.join(base, "replies-50.docx")
    build_pdf(pdf, payload.business_name, job.reviews, replies, job.signoff)
    build_docx(docx, payload.business_name, job.reviews, replies, job.signoff)
    send_email(
        to_addr=payload.email,
        subject=f"{payload.business_name} — Your 50 Review Replies (Approve/Use)",
        body="PDF and DOCX attached. Reply if you want posting service enabled.",
        attachments=[pdf, docx]
    )
    return {"ok": True, "delivered": True, "files": [pdf, docx]}

# Stripe webhook (optional; works if forwarded by Stripe CLI)
@app.post("/webhook/stripe")
async def stripe_webhook(req: Request):
    try:
        event = await req.json()
        etype = event.get("type","")
        if etype == "checkout.session.completed":
            sess = event.get("data",{}).get("object",{})
            email = (sess.get("customer_details") or {}).get("email") or sess.get("customer_email")
            cref  = sess.get("client_reference_id","")
            if email:
                send_email(
                    to_addr=email,
                    subject="Welcome — Onboarding link",
                    body=f"Thanks! Complete tone intake here: {ONBOARDING_URL}\nRef: {cref}"
                )
        return {"ok": True}
    except Exception:
        traceback.print_exc()
        raise HTTPException(400,"bad payload")
